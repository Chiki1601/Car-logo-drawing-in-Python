# 15 car logo designs

import turtle
from logos import *

win = turtle.Screen()
win.bgcolor('white')

t = turtle.Turtle()
t.width(2)
t.hideturtle()

if __name__ == '__main__':
	bmw(t)
	t.showturtle()
	turtle.done()